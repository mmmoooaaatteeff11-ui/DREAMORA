# Dreamora Project Handoff

## Product overview
Dreamora is a bilingual (Arabic-first, English also supported) wellbeing and personal-growth web app. It combines guided reflection, an AI companion, dream scenes, mood check-ins, faith features, goals/journey tracking, and the newer Nomouk World growth experience. The UI uses Next.js App Router, TypeScript, Tailwind, next-intl, and Supabase (Auth/Postgres/Storage with RLS).

## Current snapshot
This archive is a snapshot of the complete working tree at packaging time, not just the Nomouk World feature. It includes tracked and untracked project files, including current local edits. These edits are uncommitted. Git metadata is intentionally omitted, so use the file contents as the current source of truth and do not assume there is a clean baseline.

The repository's `ARCHITECTURE.md` and `PROGRESS.md` provide useful background but predate some recent work; treat them as historical notes and verify claims against the implementation.

## Nomouk World progress
- Added the localized growth/world route, server-loaded world profile/goals/obstacles, and client-side world experience.
- Added the WebGL scene engine and React scene wrapper, character/companion profile editing, fallback UI, and localization.
- Added accessible segmented controls, swatches, icon buttons, responsive world HUD/panel, and world-specific scoped styling.
- The world-specific color system lives in `src/components/world/world-theme.css`.
- `supabase/migrations/008_world.sql` and `supabase/tests/008_world_test.sql` are included. Their presence in this archive does not prove they have been applied/run in the target Supabase project; confirm before relying on the database schema.
- Current implementation was previously checked with typecheck/lint and an isolated production build. An authenticated browser visual check was not completed; the local dev server redirected to login and showed missing Next.js chunk responses.

## Important handling notes
- `.env.local`, all other non-example environment files, `.git`, `node_modules`, `.next`, build output, and TypeScript build cache are excluded.
- `.env.example` is included as a placeholder template. Never put real credentials in the archive or send them to Claude.
- The current worktree has unrelated edits alongside Nomouk World work. Review diffs before changing shared files, especially `tailwind.config.ts`, package files, navigation, translations, and existing pages/components.
- Do not overwrite or delete existing routes, migrations, or user changes. Follow the established cookie-based Supabase server client, authenticated `user.id`, RLS, Zod validation, and bilingual translation patterns.

## Suggested first steps
1. Read `ARCHITECTURE.md`, `PROGRESS.md`, and `package.json`, then inspect the current route and world components.
2. Review the current worktree file changes conceptually; this ZIP has no Git history/diff metadata.
3. Set up local environment from `.env.example` without sharing actual values.
4. Install from the lockfile (`npm ci`), then run `npm run typecheck`, `npm run lint`, and `npm run build` before making changes.
5. Confirm migration 008 and its SQL test status with the project owner/Supabase environment.

## Git status at packaging time
Branch: `dreamora-advanced-features`

```
 M messages/ar.json
 M messages/en.json
 M package-lock.json
 M package.json
 M src/app/[locale]/(app)/dashboard/page.tsx
 M src/app/[locale]/(app)/journey/page.tsx
 M src/components/layout/AppNav.tsx
 M src/components/mood/MoodCheckIn.tsx
 M src/components/ui/Button.tsx
 M tailwind.config.ts
?? src/app/[locale]/(app)/growth/
?? src/components/ui/IconButton.tsx
?? src/components/ui/Segmented.tsx
?? src/components/ui/Swatch.tsx
?? src/components/world/
?? src/lib/validation/world.ts
?? src/server/services/world.ts
?? supabase/migrations/008_world.sql
?? supabase/tests/008_world_test.sql
```