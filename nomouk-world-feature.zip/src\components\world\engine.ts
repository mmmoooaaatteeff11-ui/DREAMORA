import type { WorldGoal, WorldObstacle, WorldProfile, WorldStep } from '@/lib/validation/world';

export type CameraMode = 'top' | 'chase' | 'firstPerson';
type WorldData = {
  profile: WorldProfile;
  goals: WorldGoal[];
  obstacles: WorldObstacle[];
  steps: WorldStep[];
  moodKey: string | null;
};

export type WorldEngine = {
  update: (data: WorldData, camera: CameraMode) => void;
  dispose: () => void;
};

type Point = [number, number];
type Color = [number, number, number, number];

const PALETTE = {
  background: [0.035, 0.055, 0.12, 1] as Color,
  water: [0.07, 0.2, 0.34, 1] as Color,
  islandShadow: [0.06, 0.14, 0.2, 1] as Color,
  islands: [
    [0.22, 0.48, 0.39, 1],
    [0.29, 0.54, 0.36, 1],
    [0.42, 0.44, 0.38, 1],
    [0.18, 0.44, 0.52, 1],
    [0.41, 0.36, 0.58, 1],
    [0.58, 0.41, 0.31, 1],
  ] as Color[],
  skin: [
    [0.96, 0.75, 0.55, 1],
    [0.78, 0.52, 0.35, 1],
    [0.59, 0.36, 0.24, 1],
    [0.38, 0.23, 0.17, 1],
  ] as Color[],
  hair: [
    [0.13, 0.09, 0.13, 1],
    [0.35, 0.18, 0.12, 1],
    [0.7, 0.38, 0.16, 1],
    [0.84, 0.75, 0.49, 1],
  ] as Color[],
  shirts: [
    [0.48, 0.29, 0.82, 1],
    [0.18, 0.57, 0.72, 1],
    [0.85, 0.38, 0.4, 1],
    [0.3, 0.61, 0.43, 1],
  ] as Color[],
  companion: [
    [0.4, 0.82, 0.9, 1],
    [0.97, 0.57, 0.3, 1],
    [0.72, 0.58, 0.96, 1],
    [0.55, 0.86, 0.55, 1],
  ] as Color[],
};

const ISLANDS: Array<{ x: number; y: number; rx: number; ry: number }> = [
  { x: -1.25, y: 0.55, rx: 0.48, ry: 0.31 },
  { x: 0, y: 0.55, rx: 0.48, ry: 0.31 },
  { x: 1.25, y: 0.55, rx: 0.48, ry: 0.31 },
  { x: -1.25, y: -0.55, rx: 0.48, ry: 0.31 },
  { x: 0, y: -0.55, rx: 0.48, ry: 0.31 },
  { x: 1.25, y: -0.55, rx: 0.48, ry: 0.31 },
];

const VERTEX_SHADER = `
attribute vec2 a_position;
uniform vec2 u_camera;
uniform float u_zoom;
uniform float u_aspect;
void main() {
  vec2 position = a_position - u_camera;
  gl_Position = vec4(position.x * u_zoom / u_aspect, position.y * u_zoom, 0.0, 1.0);
}`;

const FRAGMENT_SHADER = `
precision mediump float;
uniform vec4 u_color;
void main() {
  gl_FragColor = u_color;
}`;

export function createWorldEngine(
  canvas: HTMLCanvasElement,
  initialData: WorldData,
  initialCamera: CameraMode,
): WorldEngine | null {
  const gl = canvas.getContext('webgl', { alpha: false, antialias: true });
  if (!gl) return null;

  const program = createProgram(gl);
  if (!program) return null;
  const positionAttribute = gl.getAttribLocation(program, 'a_position');
  const colorUniform = gl.getUniformLocation(program, 'u_color');
  const cameraUniform = gl.getUniformLocation(program, 'u_camera');
  const zoomUniform = gl.getUniformLocation(program, 'u_zoom');
  const aspectUniform = gl.getUniformLocation(program, 'u_aspect');
  if (
    positionAttribute < 0 ||
    colorUniform === null ||
    cameraUniform === null ||
    zoomUniform === null ||
    aspectUniform === null
  ) {
    gl.deleteProgram(program);
    return null;
  }

  const buffer = gl.createBuffer();
  if (!buffer) {
    gl.deleteProgram(program);
    return null;
  }
  gl.useProgram(program);
  gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
  gl.enableVertexAttribArray(positionAttribute);
  gl.vertexAttribPointer(positionAttribute, 2, gl.FLOAT, false, 0, 0);
  gl.enable(gl.BLEND);
  gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);

  let data = initialData;
  let camera = initialCamera;
  let frame = 0;
  let disposed = false;
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');

  const resize = () => {
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    const width = Math.max(1, Math.floor(canvas.clientWidth * ratio));
    const height = Math.max(1, Math.floor(canvas.clientHeight * ratio));
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
      gl.viewport(0, 0, width, height);
    }
  };

  const drawShape = (points: Point[], color: Color) => {
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(points.flat()), gl.STREAM_DRAW);
    gl.uniform4fv(colorUniform, color);
    gl.drawArrays(gl.TRIANGLE_FAN, 0, points.length);
  };

  const ellipse = (x: number, y: number, rx: number, ry: number, color: Color, segments = 28) => {
    const points: Point[] = [[x, y]];
    for (let index = 0; index <= segments; index += 1) {
      const angle = (index / segments) * Math.PI * 2;
      points.push([x + Math.cos(angle) * rx, y + Math.sin(angle) * ry]);
    }
    drawShape(points, color);
  };

  const rectangle = (x: number, y: number, width: number, height: number, color: Color) => {
    drawShape(
      [
        [x, y],
        [x + width, y],
        [x + width, y + height],
        [x, y + height],
      ],
      color,
    );
  };

  const triangle = (a: Point, b: Point, c: Point, color: Color) => drawShape([a, b, c], color);

  const drawWeather = (time: number) => {
    if (data.moodKey === 'sad' || data.moodKey === 'angry' || data.moodKey === 'lonely' || data.moodKey === 'anxious') {
      for (let index = 0; index < 18; index += 1) {
        const x = -1.85 + ((index * 0.43 + 0.15) % 3.7);
        const y = 0.9 - ((index * 0.37 + (reduceMotion.matches ? 0 : time * 0.25)) % 1.8);
        rectangle(x, y, 0.012, 0.07, [0.38, 0.67, 0.9, 0.55]);
      }
      ellipse(1.48, 0.84, 0.16, 0.12, [0.3, 0.39, 0.56, 1]);
      ellipse(1.63, 0.82, 0.2, 0.14, [0.3, 0.39, 0.56, 1]);
      ellipse(1.78, 0.84, 0.13, 0.1, [0.3, 0.39, 0.56, 1]);
    } else if (data.moodKey === 'tired') {
      ellipse(1.5, 0.84, 0.16, 0.11, [0.38, 0.46, 0.58, 1]);
      ellipse(1.66, 0.83, 0.2, 0.14, [0.38, 0.46, 0.58, 1]);
      ellipse(1.81, 0.84, 0.13, 0.1, [0.38, 0.46, 0.58, 1]);
    } else {
      ellipse(-1.6, 0.88, 0.15, 0.15, [0.99, 0.79, 0.43, 0.9]);
      ellipse(-1.6, 0.88, 0.09, 0.09, [1, 0.9, 0.64, 1]);
    }
  };

  const drawPerson = (x: number, y: number, skin: Color, hair: Color, shirt: Color, feminine: boolean) => {
    ellipse(x, y - 0.018, 0.055, 0.058, shirt);
    ellipse(x, y + 0.052, 0.043, 0.043, skin);
    ellipse(x, y + 0.077, 0.044, 0.022, hair);
    if (feminine) {
      triangle([x - 0.04, y + 0.072], [x - 0.012, y + 0.12], [x + 0.005, y + 0.065], hair);
      triangle([x + 0.04, y + 0.072], [x + 0.012, y + 0.12], [x - 0.005, y + 0.065], hair);
    }
  };

  const drawCompanion = (x: number, y: number, color: Color) => {
    ellipse(x, y, 0.062, 0.062, [color[0], color[1], color[2], 0.28]);
    ellipse(x, y, 0.04, 0.04, color);
    if (data.profile.companionForm === 'fox') {
      triangle([x - 0.034, y + 0.025], [x - 0.055, y + 0.09], [x - 0.005, y + 0.055], color);
      triangle([x + 0.034, y + 0.025], [x + 0.055, y + 0.09], [x + 0.005, y + 0.055], color);
    } else if (data.profile.companionForm === 'spirit') {
      ellipse(x, y - 0.009, 0.02, 0.025, [0.94, 0.96, 1, 0.9]);
    } else {
      ellipse(x - 0.014, y + 0.005, 0.005, 0.007, [0.04, 0.08, 0.13, 1]);
      ellipse(x + 0.014, y + 0.005, 0.005, 0.007, [0.04, 0.08, 0.13, 1]);
    }
  };

  const drawObstacle = (x: number, y: number, kind: WorldObstacle['kind']) => {
    if (kind === 'time') {
      ellipse(x, y, 0.075, 0.042, [0.68, 0.77, 0.88, 1]);
      ellipse(x - 0.045, y - 0.008, 0.045, 0.04, [0.68, 0.77, 0.88, 1]);
      ellipse(x + 0.045, y - 0.005, 0.052, 0.045, [0.68, 0.77, 0.88, 1]);
    } else if (kind === 'fear') {
      triangle([x - 0.055, y - 0.04], [x, y + 0.065], [x + 0.055, y - 0.04], [0.49, 0.65, 0.31, 1]);
      triangle([x - 0.015, y - 0.02], [x + 0.005, y + 0.035], [x + 0.025, y - 0.02], [0.69, 0.79, 0.48, 1]);
    } else if (kind === 'energy') {
      ellipse(x, y - 0.005, 0.058, 0.05, [0.47, 0.48, 0.53, 1]);
      triangle([x - 0.045, y - 0.02], [x - 0.02, y + 0.045], [x + 0.005, y - 0.02], [0.58, 0.59, 0.63, 1]);
    } else {
      rectangle(x - 0.055, y - 0.05, 0.11, 0.1, [0.62, 0.37, 0.28, 1]);
    }
  };

  const drawTrophy = (x: number, y: number) => {
    ellipse(x, y + 0.005, 0.045, 0.045, [1, 0.76, 0.24, 1]);
    triangle([x - 0.034, y + 0.017], [x, y + 0.072], [x + 0.034, y + 0.017], [1, 0.86, 0.44, 1]);
    rectangle(x - 0.009, y - 0.04, 0.018, 0.03, [0.94, 0.62, 0.18, 1]);
    rectangle(x - 0.03, y - 0.053, 0.06, 0.014, [0.94, 0.62, 0.18, 1]);
  };

  const render = (time: number) => {
    if (disposed) return;
    resize();
    const aspect = canvas.width / Math.max(canvas.height, 1);
    let cameraX = 0;
    let cameraY = 0;
    let zoom = 1;
    if (camera === 'chase') {
      cameraX = 0;
      cameraY = -0.55;
      zoom = 1.34;
    } else if (camera === 'firstPerson') {
      cameraX = 0;
      cameraY = -0.48;
      zoom = 1.85;
    }
    gl.clearColor(...PALETTE.background);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.uniform2f(cameraUniform, cameraX, cameraY);
    gl.uniform1f(zoomUniform, zoom);
    gl.uniform1f(aspectUniform, aspect);

    ellipse(0, 0, 2.7, 1.6, PALETTE.water, 48);
    drawWeather(time);
    ISLANDS.forEach((island, index) => {
      ellipse(island.x, island.y - 0.055, island.rx, island.ry, PALETTE.islandShadow, 32);
      ellipse(island.x, island.y, island.rx, island.ry, PALETTE.islands[index], 32);
      ellipse(island.x - 0.06, island.y + 0.03, island.rx * 0.54, island.ry * 0.34, [0.44, 0.68, 0.46, 0.42], 24);
    });

    const mountain = ISLANDS[1];
    triangle([mountain.x - 0.27, mountain.y - 0.02], [mountain.x, mountain.y + 0.27], [mountain.x + 0.29, mountain.y - 0.02], [0.31, 0.34, 0.4, 1]);
    triangle([mountain.x - 0.1, mountain.y + 0.07], [mountain.x, mountain.y + 0.27], [mountain.x + 0.12, mountain.y + 0.07], [0.84, 0.86, 0.89, 1]);

    const completedSteps = data.steps.filter((step) => step.completed_at).length;
    rectangle(-0.035, -0.3, 0.07, 0.48, [0.33, 0.23, 0.16, 1]);
    for (let index = 0; index < Math.min(completedSteps, 5); index += 1) {
      rectangle(-0.095, -0.28 + index * 0.085, 0.19, 0.025, [0.74, 0.56, 0.34, 1]);
    }

    const visibleObstacles = data.obstacles.slice(0, 6);
    visibleObstacles.forEach((obstacle, index) => {
      const x = -0.25 + (index % 3) * 0.25;
      const y = 0.46 + Math.floor(index / 3) * 0.15;
      if (obstacle.status === 'overcome') drawTrophy(x, y);
      else drawObstacle(x, y, obstacle.kind);
    });

    const bob = reduceMotion.matches ? 0 : Math.sin(time * 2.5) * 0.012;
    drawPerson(
      -0.08,
      -0.55 + bob,
      PALETTE.skin[data.profile.heroSkin],
      PALETTE.hair[data.profile.heroHair],
      PALETTE.shirts[data.profile.heroShirt],
      data.profile.heroGender === 'f',
    );
    drawCompanion(0.1, -0.54 + bob, PALETTE.companion[data.profile.companionTint]);

    if (!reduceMotion.matches) frame = window.requestAnimationFrame(render);
  };

  const renderOnce = () => render(0);
  const onMotionChange = () => {
    if (frame) window.cancelAnimationFrame(frame);
    frame = 0;
    if (reduceMotion.matches) renderOnce();
    else frame = window.requestAnimationFrame(render);
  };
  reduceMotion.addEventListener('change', onMotionChange);
  if (reduceMotion.matches) renderOnce();
  else frame = window.requestAnimationFrame(render);

  return {
    update(nextData, nextCamera) {
      data = nextData;
      camera = nextCamera;
      if (reduceMotion.matches) renderOnce();
    },
    dispose() {
      disposed = true;
      if (frame) window.cancelAnimationFrame(frame);
      reduceMotion.removeEventListener('change', onMotionChange);
      gl.deleteBuffer(buffer);
      gl.deleteProgram(program);
    },
  };
}

function createProgram(gl: WebGLRenderingContext): WebGLProgram | null {
  const vertexShader = compileShader(gl, gl.VERTEX_SHADER, VERTEX_SHADER);
  const fragmentShader = compileShader(gl, gl.FRAGMENT_SHADER, FRAGMENT_SHADER);
  if (!vertexShader || !fragmentShader) return null;
  const program = gl.createProgram();
  if (!program) return null;
  gl.attachShader(program, vertexShader);
  gl.attachShader(program, fragmentShader);
  gl.linkProgram(program);
  gl.deleteShader(vertexShader);
  gl.deleteShader(fragmentShader);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    gl.deleteProgram(program);
    return null;
  }
  return program;
}

function compileShader(
  gl: WebGLRenderingContext,
  type: number,
  source: string,
): WebGLShader | null {
  const shader = gl.createShader(type);
  if (!shader) return null;
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    gl.deleteShader(shader);
    return null;
  }
  return shader;
}
