'use client';

import { AnimatePresence, motion, useDragControls, useReducedMotion } from 'framer-motion';
import dynamic from 'next/dynamic';
import { useLocale, useTranslations } from 'next-intl';
import { useEffect, useRef, useState } from 'react';
import { IconButton } from '@/components/ui/IconButton';
import { Segmented, type SegmentOption } from '@/components/ui/Segmented';
import { WorldCharacterForm } from '@/components/world/WorldCharacterForm';
import type { CameraMode } from '@/components/world/engine';
import type { WorldGoal, WorldObstacle, WorldProfile, WorldStep } from '@/lib/validation/world';

const WorldScene = dynamic(() => import('./scene').then((module) => module.WorldScene), {
  ssr: false,
  loading: () => <SceneSkeleton />,
});

type PanelTab = 'character' | 'companion' | 'goals';

export function NomoukWorld({
  profile: initialProfile,
  goals,
  obstacles,
  steps,
  moodKey,
  loadError,
}: {
  profile: WorldProfile;
  goals: WorldGoal[];
  obstacles: WorldObstacle[];
  steps: WorldStep[];
  moodKey: string | null;
  loadError: boolean;
}) {
  const t = useTranslations('world');
  const tm = useTranslations('mood');
  const locale = useLocale();
  const reduceMotion = useReducedMotion();
  const [profile, setProfile] = useState(initialProfile);
  const [camera, setCamera] = useState<CameraMode>('top');
  const [activeTab, setActiveTab] = useState<PanelTab>('character');
  const [panelOpen, setPanelOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const panelRef = useRef<HTMLElement>(null);
  const panelToggleRef = useRef<HTMLButtonElement>(null);
  const dragControls = useDragControls();

  useEffect(() => {
    const media = window.matchMedia('(max-width: 1023px)');
    const syncViewport = () => {
      setIsMobile(media.matches);
      setPanelOpen(!media.matches);
    };
    syncViewport();
    media.addEventListener('change', syncViewport);
    return () => media.removeEventListener('change', syncViewport);
  }, []);

  useEffect(() => {
    if (!isMobile || !panelOpen) return;
    const panel = panelRef.current;
    if (!panel) return;
    const toggleButton = panelToggleRef.current;
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const getFocusable = () =>
      Array.from(
        panel.querySelectorAll<HTMLElement>(
        'button:not([disabled]), input:not([type="hidden"]):not([disabled]), [tabindex]:not([tabindex="-1"])',
        ),
      ).filter((element) => !element.closest('[hidden]') && element.getClientRects().length > 0);
    getFocusable()[0]?.focus();

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        setPanelOpen(false);
        return;
      }
      if (event.key !== 'Tab') return;
      const focusable = getFocusable();
      if (!focusable.length) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && (document.activeElement === first || !panel.contains(document.activeElement))) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && (document.activeElement === last || !panel.contains(document.activeElement))) {
        event.preventDefault();
        first.focus();
      }
    };
    document.addEventListener('keydown', onKeyDown);
    return () => {
      document.removeEventListener('keydown', onKeyDown);
      if (previousFocus?.isConnected) previousFocus.focus();
      else toggleButton?.focus();
    };
  }, [isMobile, panelOpen]);

  const activeGoal = goals[0];
  const moodLabel = getMoodLabel(moodKey, tm, t);
  const panelTabs: SegmentOption[] = [
    { value: 'character', label: t('panel.tabs.character') },
    { value: 'companion', label: t('panel.tabs.companion') },
    { value: 'goals', label: t('panel.tabs.goals') },
  ];
  const cameraOptions: SegmentOption[] = [
    {
      value: 'top',
      label: <span className="hidden sm:inline">{t('scene.cameras.top')}</span>,
      icon: <CameraIcon mode="top" />,
    },
    {
      value: 'chase',
      label: <span className="hidden sm:inline">{t('scene.cameras.chase')}</span>,
      icon: <CameraIcon mode="chase" />,
    },
    {
      value: 'firstPerson',
      label: <span className="hidden sm:inline">{t('scene.cameras.firstPerson')}</span>,
      icon: <CameraIcon mode="firstPerson" />,
    },
  ];

  return (
    <main className="relative isolate h-[calc(100dvh-7.5rem)] w-full overflow-hidden bg-[var(--w-base)] text-[var(--w-ink)] lg:h-dvh">
      <h1 className="sr-only">{t('title')}</h1>
      <WorldScene
        profile={profile}
        goals={goals}
        obstacles={obstacles}
        steps={steps}
        moodKey={moodKey}
        camera={camera}
      />

      <div className="pointer-events-none absolute inset-x-0 top-0 z-10 flex items-start justify-between gap-2 p-4 sm:p-6">
        <div className="pointer-events-auto flex min-h-11 min-w-0 max-w-[calc(100%-3.5rem)] items-center gap-2 rounded-[10px] border border-[var(--w-border)] bg-[var(--w-surface)] px-4 py-2">
          <span className="shrink-0 text-sm font-medium text-[var(--w-ink)]">{moodLabel}</span>
          <span aria-hidden="true" className="text-[var(--w-muted)]">·</span>
          <span className="truncate text-sm text-[var(--w-muted)]">
            {activeGoal?.title ?? t('scene.noActiveGoal')}
          </span>
        </div>
        <IconButton
          ref={panelToggleRef}
          icon="panel"
          aria-label={panelOpen ? t('panel.hide') : t('panel.show')}
          aria-expanded={panelOpen}
          onClick={() => setPanelOpen((open) => !open)}
          className="pointer-events-auto"
        />
      </div>

      {loadError && (
        <div
          role="alert"
          className="absolute start-4 top-20 z-10 flex max-w-[calc(100%-2rem)] items-center gap-2 rounded-[10px] border border-[var(--w-danger)] bg-[var(--w-surface)] px-4 py-3 text-sm text-[var(--w-danger)] sm:start-6"
        >
          <ErrorIcon />
          <span>{t('errors.load_failed')}</span>
        </div>
      )}

      <div className="absolute inset-x-0 bottom-4 z-10 flex justify-center px-4 lg:bottom-6">
        <Segmented
          label={t('scene.cameraLabel')}
          value={camera}
          options={cameraOptions}
          onChange={(value) => setCamera(value as CameraMode)}
          className="gap-2"
        />
      </div>

      <AnimatePresence initial={false}>
        {panelOpen && (
          <>
            <motion.aside
              ref={panelRef}
              key="world-panel"
              role={isMobile ? 'dialog' : 'complementary'}
              aria-modal={isMobile || undefined}
              aria-labelledby="world-panel-title"
              drag={isMobile ? 'y' : false}
              dragControls={dragControls}
              dragListener={false}
              dragConstraints={{ top: 0, bottom: 0 }}
              dragElastic={0.12}
              dragMomentum={false}
              onDragEnd={(_, info) => {
                if (isMobile && info.offset.y > 88) setPanelOpen(false);
              }}
              initial={panelInitial(isMobile, locale, reduceMotion)}
              animate={{ opacity: 1, x: 0, y: 0 }}
              exit={panelExit(isMobile, locale, reduceMotion)}
              transition={reduceMotion ? { duration: 0 } : { type: 'spring', stiffness: 320, damping: 34 }}
              className={`absolute z-30 flex min-h-0 flex-col overflow-hidden border border-[var(--w-border)] bg-[var(--w-surface)] ${
                isMobile
                  ? 'inset-x-0 bottom-0 max-h-[82%] rounded-t-[12px]'
                  : 'inset-y-4 end-4 w-[380px] max-w-[calc(100%-2rem)] rounded-[12px]'
              }`}
            >
              {isMobile && (
                <div
                  role="separator"
                  aria-orientation="horizontal"
                  aria-label={t('panel.drag')}
                  onPointerDown={(event) => dragControls.start(event)}
                  className="flex h-8 shrink-0 cursor-grab touch-none items-center justify-center active:cursor-grabbing"
                >
                  <span className="h-1 w-10 rounded-full bg-[var(--w-muted)]" />
                </div>
              )}
              <div className="flex items-start justify-between gap-2 px-4 pb-4 pt-2">
                <div className="min-w-0">
                  <h2 id="world-panel-title" className="font-heading text-xl font-semibold text-[var(--w-ink)]">
                    {t('panel.title')}
                  </h2>
                  <p className="mt-2 text-sm text-[var(--w-muted)]">{t('panel.description')}</p>
                </div>
                {isMobile && (
                  <IconButton
                    icon="close"
                    aria-label={t('panel.close')}
                    onClick={() => setPanelOpen(false)}
                  />
                )}
              </div>

              <div className="px-4 pb-4">
                <Segmented
                  label={t('panel.tabs.label')}
                  value={activeTab}
                  options={panelTabs}
                  onChange={(value) => setActiveTab(value as PanelTab)}
                  className="grid w-full grid-cols-3 gap-2"
                />
              </div>

              <div className="min-h-0 flex-1 overflow-y-auto px-4 pb-4">
                {activeTab === 'goals' ? (
                  <GoalsPanel goals={goals} obstacles={obstacles} />
                ) : (
                  <WorldCharacterForm profile={profile} section={activeTab} onProfileChange={setProfile} />
                )}
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </main>
  );
}

function GoalsPanel({ goals, obstacles }: { goals: WorldGoal[]; obstacles: WorldObstacle[] }) {
  const t = useTranslations('world');
  if (!goals.length) {
    return (
      <p className="rounded-[10px] border border-[var(--w-border)] bg-[var(--w-surface)] px-4 py-4 text-sm text-[var(--w-muted)]">
        {t('goals.empty')}
      </p>
    );
  }
  return (
    <ul className="space-y-2">
      {goals.map((goal) => {
        const related = obstacles.filter((obstacle) => obstacle.goal_id === goal.id);
        const open = related.filter((obstacle) => obstacle.status === 'open').length;
        const overcome = related.length - open;
        return (
          <li key={goal.id} className="space-y-4 rounded-[10px] border border-[var(--w-border)] bg-[var(--w-surface)] p-4">
            <p className="text-sm font-medium text-[var(--w-ink)]">{goal.title}</p>
            <div className="flex flex-wrap gap-2">
              <WorldBadge>{t('panel.openCount', { count: open })}</WorldBadge>
              <WorldBadge tone="overcome">{t('panel.overcomeCount', { count: overcome })}</WorldBadge>
            </div>
          </li>
        );
      })}
    </ul>
  );
}

function SceneSkeleton() {
  return (
    <div aria-hidden="true" className="absolute inset-0 bg-[var(--w-base)]">
      <div className="world-skeleton absolute start-4 top-4 h-11 w-56 rounded-[10px] border border-[var(--w-border)] sm:start-6 sm:top-6" />
      <div className="world-skeleton absolute end-4 top-4 h-11 w-11 rounded-[10px] border border-[var(--w-border)] sm:end-6 sm:top-6" />
      <div className="world-skeleton absolute inset-x-1/4 top-1/4 h-1/2 rounded-[12px] border border-[var(--w-border)]" />
      <div className="world-skeleton absolute bottom-4 start-1/3 h-11 w-1/3 rounded-[10px] border border-[var(--w-border)] lg:bottom-6" />
    </div>
  );
}

function WorldBadge({ children, tone = 'open' }: { children: string; tone?: 'open' | 'overcome' }) {
  return (
    <span
      className={`rounded-[10px] border border-[var(--w-border)] bg-[var(--w-surface)] px-4 py-2 text-sm ${
        tone === 'overcome' ? 'text-[var(--w-sand)]' : 'text-[var(--w-muted)]'
      }`}
    >
      {children}
    </span>
  );
}

function ErrorIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      className="h-5 w-5 shrink-0"
    >
      <circle cx="12" cy="12" r="9" />
      <path d="M12 8v5M12 16h.01" />
    </svg>
  );
}

function CameraIcon({ mode }: { mode: CameraMode }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      className="h-5 w-5 shrink-0"
    >
      {mode === 'top' ? (
        <>
          <path d="M12 3v18M8 7l4-4 4 4M8 17l4 4 4-4" />
          <circle cx="12" cy="12" r="2" />
        </>
      ) : mode === 'chase' ? (
        <>
          <circle cx="12" cy="7" r="2" />
          <path d="M8 20v-3a4 4 0 0 1 8 0v3M4 8v8M2.5 10h3" />
        </>
      ) : (
        <>
          <path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z" />
          <circle cx="12" cy="12" r="2.5" />
        </>
      )}
    </svg>
  );
}

function getMoodLabel(
  moodKey: string | null,
  tm: ReturnType<typeof useTranslations<'mood'>>,
  t: ReturnType<typeof useTranslations<'world'>>,
) {
  if (
    moodKey === 'joyful' ||
    moodKey === 'grateful' ||
    moodKey === 'calm' ||
    moodKey === 'hopeful' ||
    moodKey === 'motivated' ||
    moodKey === 'tired' ||
    moodKey === 'anxious' ||
    moodKey === 'sad' ||
    moodKey === 'angry' ||
    moodKey === 'lonely'
  ) {
    return tm(`moods.${moodKey}`);
  }
  return t('scene.weather.clearShort');
}

function panelInitial(isMobile: boolean, locale: string, reduceMotion: boolean | null) {
  if (reduceMotion) return false;
  return isMobile ? { opacity: 0, y: '100%' } : { opacity: 0, x: locale === 'ar' ? -24 : 24 };
}

function panelExit(isMobile: boolean, locale: string, reduceMotion: boolean | null) {
  if (reduceMotion) return { opacity: 0 };
  return isMobile ? { opacity: 0, y: '100%' } : { opacity: 0, x: locale === 'ar' ? -24 : 24 };
}
