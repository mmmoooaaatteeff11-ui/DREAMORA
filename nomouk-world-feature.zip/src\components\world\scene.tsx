'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { useTranslations } from 'next-intl';
import { createWorldEngine, type CameraMode, type WorldEngine } from '@/components/world/engine';
import type { WorldGoal, WorldObstacle, WorldProfile, WorldStep } from '@/lib/validation/world';

export function WorldScene({
  profile,
  goals,
  obstacles,
  steps,
  moodKey,
  camera,
}: {
  profile: WorldProfile;
  goals: WorldGoal[];
  obstacles: WorldObstacle[];
  steps: WorldStep[];
  moodKey: string | null;
  camera: CameraMode;
}) {
  const t = useTranslations('world');
  const sceneData = useMemo(() => ({ profile, goals, obstacles, steps, moodKey }), [profile, goals, obstacles, steps, moodKey]);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<WorldEngine | null>(null);
  const sceneDataRef = useRef(sceneData);
  const cameraRef = useRef(camera);
  const [supported, setSupported] = useState<boolean | null>(null);

  useEffect(() => {
    sceneDataRef.current = sceneData;
    cameraRef.current = camera;
    engineRef.current?.update(sceneData, camera);
  }, [sceneData, camera]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const engine = createWorldEngine(canvas, sceneDataRef.current, cameraRef.current);
    if (!engine) {
      setSupported(false);
      return;
    }
    engineRef.current = engine;
    setSupported(true);
    return () => {
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  if (supported === false) {
    return (
      <div
        className="absolute inset-0 overflow-auto rounded-[10px] border border-[var(--w-border)] bg-[var(--w-surface)] p-6 text-[var(--w-ink)]"
        role="status"
      >
        <p className="font-medium text-[var(--w-ink)]">{t('scene.fallbackTitle')}</p>
        <p className="mt-2 text-sm text-[var(--w-muted)]">{t('scene.fallbackDescription')}</p>
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <div>
            <h3 className="text-sm font-semibold text-[var(--w-ink)]">{t('goals.title')}</h3>
            <ul className="mt-2 list-inside list-disc space-y-2 text-sm text-[var(--w-muted)]">
              {goals.length ? goals.map((goal) => <li key={goal.id}>{goal.title}</li>) : <li>{t('goals.empty')}</li>}
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-semibold text-[var(--w-ink)]">{t('obstacles.title')}</h3>
            <ul className="mt-2 list-inside list-disc space-y-2 text-sm text-[var(--w-muted)]">
              {obstacles.length
                ? obstacles.map((obstacle) => <li key={obstacle.id}>{obstacle.title}</li>)
                : <li>{t('obstacles.empty')}</li>}
            </ul>
          </div>
        </div>
      </div>
    );
  }

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 block h-full w-full bg-[var(--w-base)]"
      aria-label={t('scene.canvasLabel')}
      aria-hidden={supported !== true}
    />
  );
}
